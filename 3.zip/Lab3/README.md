Третя лабораторна на EF Core з InMemoryDatabase
